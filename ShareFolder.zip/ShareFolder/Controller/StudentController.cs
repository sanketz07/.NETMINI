﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mini_Project__.NET_Framework_.Controller
{
    public class StudentController 
    {
        public void studentRole() { }
        public void studentInfo()
        {
            
        }
    }
}
